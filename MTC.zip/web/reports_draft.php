<?php include 'header.php'
?>
<body>
    <div class="wrapper">
        
                <?php
                    include 'sidebar.php';
                ?>
 
          
            <div id="content">
        
                <?php
                    include 'top_navbar.php';
                    include 'reports_sales.php';
                ?>
                
            <div>
            
    </div>
    <?php include 'footer.php'
    ?>
</body>
</html>