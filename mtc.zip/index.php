<?php
header("Location: web/login.php"); /* Redirect browser */
exit();
?>
