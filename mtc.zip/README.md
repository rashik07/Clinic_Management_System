# hms
Hospital Management System

# API Documentaion
https://documenter.getpostman.com/view/1175682/TzecDkWc
